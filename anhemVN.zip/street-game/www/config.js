window.MG_SERVER="";
