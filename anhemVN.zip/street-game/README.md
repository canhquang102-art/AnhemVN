# Mini GTA 3D — chơi chung PC + điện thoại

Gồm: **máy chủ** (`server.js`), **game** (`www/`), và cách đóng gói ra **MiniGTA-PC.exe** + **MiniGTA-Phone.apk**.
File .exe đã có sẵn máy chủ bên trong: ai mở .exe là thành chủ phòng.

## Cách 1 — Thử ngay, không cần APK/EXE
Cần cài Node.js (https://nodejs.org). Mở thư mục này, chạy:

    node server.js

PC mở `http://localhost:3000`. Điện thoại (cùng Wi-Fi) mở trình duyệt vào địa chỉ `http://<IP máy tính>:3000` (máy chủ in sẵn địa chỉ này). Chọn **Chơi online** → đăng ký → vào chơi chung.

## Cách 2 — Lấy 2 file .exe và .apk (miễn phí, build trên GitHub)
1. Tạo repository mới trên github.com, upload **toàn bộ** thư mục này (nhớ cả thư mục `.github`).
2. Vào tab **Actions** → **Build EXE va APK** → **Run workflow**.
3. Chờ ~10–15 phút, mở lần chạy đó, kéo xuống **Artifacts** và tải:
   - `MiniGTA-PC-exe` → `MiniGTA-PC.exe`
   - `MiniGTA-Phone-apk` → `MiniGTA-Phone.apk`

## Cách chơi chung
1. **PC:** mở `MiniGTA-PC.exe` (Windows hỏi tường lửa → *Cho phép*). Hộp thoại hiện địa chỉ, ví dụ `http://192.168.1.5:3000` (xem lại bằng phím F1). Trong game bấm **Chơi online** → đăng ký → vào.
2. **Điện thoại:** cài `MiniGTA-Phone.apk` (bật "cài từ nguồn không rõ"), bấm **Chơi online**, ô *Địa chỉ máy chủ* nhập địa chỉ ở trên, đăng nhập bằng tài khoản của mình.
3. Hai bên cùng Wi-Fi là thấy nhau.

## Chơi khác mạng (qua Internet)
Chạy tunnel tới cổng 3000 (Cloudflare Tunnel, ngrok, playit.gg…) hoặc đặt `server.js` lên VPS, rồi nhập địa chỉ đó vào ô *Địa chỉ máy chủ* trên điện thoại.

## Ghi chú
- APK là bản debug (đã ký sẵn, cài được). Muốn đưa lên CH Play cần tạo bản release.
- EXE chưa có chữ ký số nên Windows SmartScreen có thể cảnh báo: *More info → Run anyway*.
- Tài khoản lưu trong `users.json` (mật khẩu băm scrypt). Tối đa 32 người cùng lúc.
- `www/three.min.js` được tự thêm lúc build để chạy được khi không có Internet.
