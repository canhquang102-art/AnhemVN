// Cho phép HTTP trong mạng LAN + xoay ngang màn hình cho app Android
const fs = require('fs'), path = require('path');
const f = path.join(__dirname, '..', 'android', 'app', 'src', 'main', 'AndroidManifest.xml');
let s = fs.readFileSync(f, 'utf8');
if (!s.includes('usesCleartextTraffic')) s = s.replace('<application', '<application android:usesCleartextTraffic="true"');
if (!s.includes('screenOrientation')) s = s.replace('<activity', '<activity android:screenOrientation="sensorLandscape"');
fs.writeFileSync(f, s);
console.log('Đã sửa AndroidManifest.xml');
