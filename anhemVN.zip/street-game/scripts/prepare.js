// Chép three.min.js (r128) vào www để game chạy được cả khi không có Internet
const fs = require('fs'), path = require('path');
const src = path.join(__dirname, '..', 'node_modules', 'three', 'build', 'three.min.js');
const dst = path.join(__dirname, '..', 'www', 'three.min.js');
if (fs.existsSync(src)) { fs.copyFileSync(src, dst); console.log('Đã chép three.min.js'); }
else console.log('Không thấy three trong node_modules — game sẽ tải three.js từ CDN (cần Internet).');
