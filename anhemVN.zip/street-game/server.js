'use strict';
/* Máy chủ chơi chung cho Mini GTA 3D — không cần cài thư viện nào.
   - Phục vụ game (thư mục www) cho trình duyệt/điện thoại
   - POST /api/register, /api/login  -> { token, name }
   - WebSocket /ws?token=...         -> trao đổi vị trí người chơi */
const http = require('http');
const fs = require('fs');
const path = require('path');
const os = require('os');
const crypto = require('crypto');

const NAMERE = /^[A-Za-z0-9_]{3,16}$/;
const MAX_PLAYERS = 32, MAX_MSG = 4096, TOKEN_DAYS = 30, TICK_MS = 66, IDLE_MS = 60000;
const MIME = {
  '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css',
  '.json': 'application/json', '.png': 'image/png', '.jpg': 'image/jpeg', '.svg': 'image/svg+xml',
  '.ico': 'image/x-icon', '.mp3': 'audio/mpeg', '.ogg': 'audio/ogg', '.wav': 'audio/wav', '.woff2': 'font/woff2'
};

function getIPs() {
  const out = [];
  for (const list of Object.values(os.networkInterfaces()))
    for (const i of list || []) if (i.family === 'IPv4' && !i.internal) out.push(i.address);
  const rank = a => (/^192\.168\./.test(a) ? 0 : /^10\./.test(a) ? 1 : /^172\.(1[6-9]|2\d|3[01])\./.test(a) ? 2 : 3);
  return out.sort((a, b) => rank(a) - rank(b));
}

function start(opts = {}) {
  const wwwDir = path.resolve(opts.wwwDir || path.join(__dirname, 'www'));
  const dataDir = path.resolve(opts.dataDir || path.join(__dirname, 'data'));
  const log = opts.log || (() => {});
  fs.mkdirSync(dataDir, { recursive: true });
  const dbFile = path.join(dataDir, 'users.json');

  let db = { secret: crypto.randomBytes(32).toString('hex'), users: {} };
  try { db = Object.assign(db, JSON.parse(fs.readFileSync(dbFile, 'utf8'))); } catch (_) {}
  const save = () => {
    const tmp = dbFile + '.tmp';
    fs.writeFileSync(tmp, JSON.stringify(db));
    fs.renameSync(tmp, dbFile);
  };
  save();

  /* ---------- tài khoản ---------- */
  const hashPw = (pw, saltHex) => crypto.scryptSync(pw, Buffer.from(saltHex, 'hex'), 32).toString('hex');
  const sign = s => crypto.createHmac('sha256', db.secret).update(s).digest('hex');
  const makeToken = name => { const exp = Date.now() + TOKEN_DAYS * 864e5; return name + '.' + exp + '.' + sign(name + '.' + exp); };
  function checkToken(t) {
    const p = String(t || '').split('.');
    if (p.length !== 3 || !NAMERE.test(p[0]) || !(+p[1] > Date.now())) return null;
    const a = Buffer.from(sign(p[0] + '.' + p[1])), b = Buffer.from(p[2]);
    if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) return null;
    const u = db.users[p[0].toLowerCase()];
    return u ? u.name : null;
  }

  const hits = new Map(); // giới hạn số lần đăng nhập/đăng ký theo IP
  function limited(ip) {
    const now = Date.now(), arr = (hits.get(ip) || []).filter(t => now - t < 60000);
    arr.push(now); hits.set(ip, arr);
    return arr.length > 20;
  }

  function sendJson(res, code, obj) {
    res.writeHead(code, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
    res.end(JSON.stringify(obj));
  }

  function handleApi(req, res, route) {
    if (route === 'ping') return sendJson(res, 200, { ok: true, players: clients.size });
    if (req.method !== 'POST' || (route !== 'register' && route !== 'login')) return sendJson(res, 404, { error: 'Không tìm thấy' });
    let body = '', dead = false;
    req.on('data', c => { body += c; if (body.length > 1024) { dead = true; req.destroy(); } });
    req.on('end', () => {
      if (dead) return;
      if (limited(req.socket.remoteAddress)) return sendJson(res, 429, { error: 'Thử quá nhiều lần, hãy chờ một phút' });
      let j; try { j = JSON.parse(body); } catch (_) { return sendJson(res, 400, { error: 'Dữ liệu không hợp lệ' }); }
      const name = j && typeof j.name === 'string' ? j.name.trim() : '', pw = j && typeof j.pw === 'string' ? j.pw : '';
      if (!NAMERE.test(name)) return sendJson(res, 400, { error: 'Tên tài khoản: 3-16 ký tự, chỉ gồm chữ không dấu, số và _' });
      if (pw.length < 6 || pw.length > 100) return sendJson(res, 400, { error: 'Mật khẩu cần từ 6 đến 100 ký tự' });
      const key = name.toLowerCase();
      if (route === 'register') {
        if (db.users[key]) return sendJson(res, 409, { error: 'Tên này đã có người dùng' });
        const salt = crypto.randomBytes(16).toString('hex');
        db.users[key] = { name, salt, hash: hashPw(pw, salt) };
        save();
        log('Tài khoản mới: ' + name);
        return sendJson(res, 200, { token: makeToken(name), name });
      }
      const u = db.users[key];
      let ok = false;
      if (u) { const a = Buffer.from(hashPw(pw, u.salt)), b = Buffer.from(u.hash); ok = a.length === b.length && crypto.timingSafeEqual(a, b); }
      if (!ok) return sendJson(res, 401, { error: 'Sai tên hoặc mật khẩu' });
      sendJson(res, 200, { token: makeToken(u.name), name: u.name });
    });
  }

  /* ---------- HTTP: game + API ---------- */
  const server = http.createServer((req, res) => {
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
    res.setHeader('Access-Control-Allow-Private-Network', 'true');
    if (req.method === 'OPTIONS') { res.writeHead(204); return res.end(); }
    let pathname;
    try { pathname = decodeURIComponent(new URL(req.url, 'http://x').pathname); } catch (_) { res.writeHead(400); return res.end(); }
    if (pathname.startsWith('/api/')) return handleApi(req, res, pathname.slice(5));
    if (pathname === '/') pathname = '/index.html';
    const file = path.resolve(path.join(wwwDir, pathname));
    if (file !== wwwDir && !file.startsWith(wwwDir + path.sep)) { res.writeHead(403); return res.end(); }
    fs.readFile(file, (err, data) => {
      if (err) { res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' }); return res.end('Not found'); }
      res.writeHead(200, { 'Content-Type': MIME[path.extname(file).toLowerCase()] || 'application/octet-stream', 'Cache-Control': 'no-cache' });
      res.end(data);
    });
  });

  /* ---------- WebSocket tối giản (RFC 6455) ---------- */
  const clients = new Map(); // tên -> { sock, d, last }
  let rev = 0;
  const frame = (op, payload) => {
    const len = payload.length; let h;
    if (len < 126) h = Buffer.from([0x80 | op, len]);
    else if (len < 65536) { h = Buffer.alloc(4); h[0] = 0x80 | op; h[1] = 126; h.writeUInt16BE(len, 2); }
    else { h = Buffer.alloc(10); h[0] = 0x80 | op; h[1] = 127; h.writeBigUInt64BE(BigInt(len), 2); }
    return Buffer.concat([h, payload]);
  };
  const sendText = (sock, s) => { if (!sock.destroyed && sock.writable) sock.write(frame(1, Buffer.from(s))); };
  function closeWs(sock, code) {
    try { const b = Buffer.alloc(2); b.writeUInt16BE(code); sock.write(frame(8, b)); } catch (_) {}
    sock.end();
  }

  const num = (v, lim) => (typeof v === 'number' && isFinite(v) ? Math.max(-lim, Math.min(lim, v)) : 0);
  const bit = v => (v ? 1 : 0);
  function clean(d) {
    if (!d || typeof d !== 'object') return null;
    return {
      n: String(d.n || 'Player').slice(0, 18), c: num(d.c, 0xffffff), x: num(d.x, 1e5), z: num(d.z, 1e5),
      h: num(d.h, 1e3), y: num(d.y, 1e4), cv: bit(d.cv), cm: bit(d.cm), cc: num(d.cc, 0xffffff), al: bit(d.al)
    };
  }

  function attach(sock, name) {
    let buf = Buffer.alloc(0), frags = [], fop = 0;
    const me = { sock, d: null, last: Date.now() };
    const old = clients.get(name);
    if (old) { closeWs(old.sock, 4002); }
    clients.set(name, me); rev++;
    log('Vào phòng: ' + name + ' (' + clients.size + ' người)');
    let gone = false;
    const leave = () => {
      if (gone) return; gone = true;
      if (clients.get(name) === me) { clients.delete(name); rev++; log('Rời phòng: ' + name); }
    };
    sock.on('data', chunk => {
      buf = Buffer.concat([buf, chunk]);
      if (buf.length > MAX_MSG * 4) return sock.destroy();
      for (;;) {
        if (buf.length < 2) return;
        const b0 = buf[0], b1 = buf[1], fin = !!(b0 & 0x80), op = b0 & 15;
        let len = b1 & 127, off = 2;
        if (!(b1 & 0x80)) return sock.destroy(); // khung từ client bắt buộc có mask
        if (len === 126) { if (buf.length < 4) return; len = buf.readUInt16BE(2); off = 4; }
        else if (len === 127) { if (buf.length < 10) return; const big = buf.readBigUInt64BE(2); if (big > BigInt(MAX_MSG)) return sock.destroy(); len = Number(big); off = 10; }
        if (len > MAX_MSG) return sock.destroy();
        if (buf.length < off + 4 + len) return;
        const mask = buf.subarray(off, off + 4), p = Buffer.from(buf.subarray(off + 4, off + 4 + len));
        for (let i = 0; i < len; i++) p[i] ^= mask[i & 3];
        buf = buf.subarray(off + 4 + len);
        me.last = Date.now();
        if (op === 8) { try { sock.end(frame(8, p.subarray(0, 2))); } catch (_) {} return; }
        if (op === 9) { sock.write(frame(10, p)); continue; }
        if (op === 10) continue;
        if (op === 1 || op === 2 || op === 0) {
          if (op !== 0) { fop = op; frags = [p]; } else frags.push(p);
          if (fin) {
            const m = Buffer.concat(frags); frags = [];
            if (fop === 1 && m.length <= 600) {
              try { const j = JSON.parse(m.toString('utf8')); if (j && j.t === 'p') { const d = clean(j.d); if (d) { me.d = d; rev++; } } } catch (_) {}
            }
          }
        }
      }
    });
    sock.on('close', leave); sock.on('error', leave); sock.on('end', leave);
  }

  server.on('upgrade', (req, sock) => {
    let url; try { url = new URL(req.url, 'http://x'); } catch (_) { return sock.destroy(); }
    const key = req.headers['sec-websocket-key'];
    if (url.pathname !== '/ws' || !key || String(req.headers.upgrade).toLowerCase() !== 'websocket') return sock.destroy();
    sock.write('HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Accept: ' +
      crypto.createHash('sha1').update(key + '258EAFA5-E914-47DA-95CA-C5AB0DC85B11').digest('base64') + '\r\n\r\n');
    sock.setNoDelay(true);
    sock.on('error', () => {});
    const name = checkToken(url.searchParams.get('token'));
    if (!name) return closeWs(sock, 4001);              // token sai/hết hạn: client không tự kết nối lại
    if (clients.size >= MAX_PLAYERS && !clients.has(name)) return closeWs(sock, 4003);
    attach(sock, name);
  });

  /* ---------- gửi trạng thái cho mọi người ---------- */
  let sentRev = -1;
  const tick = setInterval(() => {
    const now = Date.now();
    for (const [n, c] of clients) if (now - c.last > IDLE_MS) { closeWs(c.sock, 4004); clients.delete(n); rev++; }
    if (rev === sentRev || !clients.size) return;
    sentRev = rev;
    const all = [];
    for (const [n, c] of clients) if (c.d) all.push({ i: n, d: c.d });
    for (const [n, c] of clients) sendText(c.sock, JSON.stringify({ t: 's', p: all.filter(x => x.i !== n) }));
  }, TICK_MS);

  /* ---------- mở cổng (thử 3000..3010) ---------- */
  return new Promise((resolve, reject) => {
    let port = opts.port || +process.env.PORT || 3000;
    const first = port;
    const tryListen = () => {
      server.once('error', e => {
        if (e.code === 'EADDRINUSE' && port < first + 10) { port++; tryListen(); } else reject(e);
      });
      server.listen(port, '0.0.0.0', () => {
        server.removeAllListeners('error');
        resolve({
          port, ips: getIPs(), server,
          stop: () => { clearInterval(tick); for (const c of clients.values()) c.sock.destroy(); server.close(); }
        });
      });
    };
    tryListen();
  });
}

module.exports = { start, getIPs };

if (require.main === module) {
  start({ log: m => console.log(new Date().toLocaleTimeString() + '  ' + m) }).then(({ port, ips }) => {
    console.log('\n=== Mini GTA 3D — máy chủ đang chạy ===');
    console.log('Trên máy này:   http://localhost:' + port);
    for (const ip of ips) console.log('Điện thoại nhập: http://' + ip + ':' + port);
    console.log('(điện thoại phải cùng Wi-Fi với máy này)\n');
  }).catch(e => { console.error('Không mở được máy chủ:', e.message); process.exit(1); });
}
