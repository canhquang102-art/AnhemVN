const { app, BrowserWindow, Menu, dialog } = require('electron');
const path = require('path');
const server = require('../server');

let win, info;
const addrText = () => info.ips.length
  ? info.ips.map(ip => 'http://' + ip + ':' + info.port).join('\n')
  : 'Không tìm thấy mạng. Hãy kết nối Wi-Fi rồi mở lại.';

function showAddress() {
  dialog.showMessageBox(win, {
    type: 'info', title: 'Địa chỉ cho điện thoại', buttons: ['OK'],
    message: 'Trên điện thoại: mở app Mini GTA 3D → Chơi online → ô "Địa chỉ máy chủ", nhập một trong các địa chỉ:',
    detail: addrText() + '\n\nĐiện thoại phải cùng Wi-Fi với máy tính này.\nLần đầu Windows hỏi tường lửa: bấm "Cho phép truy nhập".'
  });
}

app.whenReady().then(async () => {
  try {
    info = await server.start({
      dataDir: app.getPath('userData'),
      wwwDir: path.join(__dirname, '..', 'www')
    });
  } catch (e) {
    dialog.showErrorBox('Không mở được máy chủ', String(e.message || e));
    return app.quit();
  }
  win = new BrowserWindow({ width: 1280, height: 720, backgroundColor: '#14161b', autoHideMenuBar: false, title: 'Mini GTA 3D' });
  Menu.setApplicationMenu(Menu.buildFromTemplate([
    { label: 'Chơi chung', submenu: [
      { label: 'Xem địa chỉ cho điện thoại', accelerator: 'F1', click: showAddress },
      { type: 'separator' }, { role: 'quit', label: 'Thoát' } ] },
    { label: 'Màn hình', submenu: [{ role: 'togglefullscreen', label: 'Toàn màn hình (F11)' }, { role: 'reload', label: 'Tải lại' }] }
  ]));
  win.loadURL('http://localhost:' + info.port);
  win.webContents.once('did-finish-load', showAddress);
});
app.on('window-all-closed', () => app.quit());
